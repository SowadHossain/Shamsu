"""
shamsu/cli/repl.py — Dev C owns this file.

Minimal REPL shell for Day 1. This is intentionally thin — it proves
the wiring (input -> stub coordinator -> output) works end to end.
Real prompt_toolkit Application with history/keybindings is the Day 1
afternoon task; this version is enough to unblock everyone else's
manual testing immediately.
"""
from __future__ import annotations

import sys
from pathlib import Path


def main() -> None:
    print("SHAMSU v0.3.0 — local AI coding agent")
    print("Type a request, or 'exit' to quit.\n")

    workspace = Path.cwd()
    print(f"Workspace: {workspace}")

    while True:
        try:
            user_input = input("shamsu> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            sys.exit(0)

        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit"):
            print("Goodbye.")
            break

        # Day 1 stub — real Coordinator wiring lands Day 4 (see WEEK3_PLAN.md)
        print(f"[stub] Received: {user_input!r}")
        print("[stub] Coordinator not wired yet — this just echoes input.\n")


if __name__ == "__main__":
    main()
